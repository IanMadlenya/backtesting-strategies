#' update ending equity for an account
#' 
#' Calculates End.Eq and Net.Performance
#' 
#' Requires that updateAcct has been run and any additional functions
#' have alread appended information into that table (e.g., additions or
#' withdrawals, fees, interest, etc.)
#' 
#' @param Account string identifying account
#' @param Dates Dates from which to calculate equity account
#' @author Peter Carl, Brian G. Peterson
#' @export
updateEndEq <- function(Account, Dates=NULL)
{
	aname<-Account
    Account<-try(get(paste("account",aname,sep='.'), envir=.blotter), silent=TRUE)
    if(inherits(Account,"try-error"))
        stop("Account ", aname, " not found, use initAcct() to create a new account")
    
    if(is.null(Dates)) # if no date is specified, get all available dates
        Dates = index(Account$summary)[-1]
    else
        Dates = index(Account$summary[Dates])
    # if the account summary table only has one observation
    # then we haven't made any transactions, so there's nothing to update
    if(!length(Dates))
        return(aname)

    PrevDate = index(Account$summary[first(Account$summary[Dates,which.i=TRUE])-1,]) # get index of previous end date 
    PrevEndEq = getEndEq(aname, PrevDate)
    Additions = Account$summary[Dates]$Additions
    Withdrawals = Account$summary[Dates]$Withdrawals
    NetPerformance = rowSums(Account$summary[Dates,c('Interest','Net.Trading.PL', 'Advisory.Fees')])
	# assign NetPerformance into the account slot 
    Account$summary$Net.Performance[Dates] <- NetPerformance

    # Create a vector of end equity
    EndCapital = PrevEndEq + cumsum(Additions + Withdrawals + NetPerformance) 
    Account$summary$End.Eq[Dates] <- EndCapital
	
	  assign(paste("account",aname,sep='.'),Account, envir=.blotter) 
    return(aname) #not sure this is a good idea
}

###############################################################################
# Blotter: Tools for transaction-oriented trading systems development
# for R (see http://r-project.org/) 
# Copyright (c) 2008-2014 Peter Carl and Brian G. Peterson
#
# This library is distributed under the terms of the GNU Public License (GPL)
# for full details see the file COPYING
#
# $Id: updateEndEq.R 1641 2014-10-21 02:57:11Z bodanker $
#
###############################################################################
