blotter
=======
Copy of https://r-forge.r-project.org/scm/viewvc.php/pkg/blotter/?root=blotter which is the authoritative repository.

Bug reports, issues, feature requests at: https://r-forge.r-project.org/tracker/?group_id=316

Mailing list: https://stat.ethz.ch/mailman/listinfo/r-sig-finance

Stack Overflow tags: blotter, quatstrat, quantmod http://stackoverflow.com/search?q=blotter
